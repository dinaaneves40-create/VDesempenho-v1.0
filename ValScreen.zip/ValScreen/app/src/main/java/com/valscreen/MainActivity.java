package com.valscreen;

import android.app.Activity;
import android.app.ActivityManager;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {

    private TextView statusText;
    private Button openGameButton;
    private Button configButton;

    private SharedPreferences preferences;

    private static final String VALORANT_PACKAGE =
        "com.tencent.tmgp.codev";

    private static final long MIN_RAM_BYTES =
        3L * 1024L * 1024L * 1024L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

        statusText = (TextView)
            findViewById(R.id.statusText);

        openGameButton = (Button)
            findViewById(R.id.openGameButton);

        configButton = (Button)
            findViewById(R.id.configButton);

        preferences = getSharedPreferences(
            "ValScreenSettings",
            MODE_PRIVATE
        );

        checkDeviceAndGame();

        configButton.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(
                        MainActivity.this,
                        ConfigActivity.class
                    );

                    startActivity(intent);
                }
            }
        );

        openGameButton.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openValorant();
                }
            }
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (preferences != null) {
            checkDeviceAndGame();
        }
    }

    private long getTotalRam() {

        ActivityManager manager =
            (ActivityManager) getSystemService(
                ACTIVITY_SERVICE
            );

        if (manager == null) {
            return 0;
        }

        ActivityManager.MemoryInfo info =
            new ActivityManager.MemoryInfo();

        manager.getMemoryInfo(info);

        return info.totalMem;
    }

    private long getAvailableRam() {

        ActivityManager manager =
            (ActivityManager) getSystemService(
                ACTIVITY_SERVICE
            );

        if (manager == null) {
            return 0;
        }

        ActivityManager.MemoryInfo info =
            new ActivityManager.MemoryInfo();

        manager.getMemoryInfo(info);

        return info.availMem;
    }

    private String formatRam(long bytes) {

        if (bytes <= 0) {
            return "Desconhecida";
        }

        double gb =
            (double) bytes /
            (1024.0 * 1024.0 * 1024.0);

        return String.format(
            Locale.US,
            "%.1f GB",
            gb
        );
    }

    private boolean isValorantInstalled() {

        try {

            getPackageManager().getPackageInfo(
                VALORANT_PACKAGE,
                0
            );

            return true;

        } catch (PackageManager.NameNotFoundException e) {

            return false;
        }
    }

    private void checkDeviceAndGame() {

        long totalRam = getTotalRam();
        long availableRam = getAvailableRam();

        boolean ramOk =
            totalRam >= MIN_RAM_BYTES;

        boolean gameOk =
            isValorantInstalled();

        boolean ultra =
            preferences.getBoolean(
                "ultraPerformance",
                false
            );

        if (!gameOk) {

            statusText.setText(
                "VALORANT Mobile não encontrado\n\n" +
                "RAM: " +
                formatRam(totalRam) +
                "\n" +
                "Requisito VDesempenho: 3 GB+"
            );

            openGameButton.setEnabled(false);

            return;
        }

        openGameButton.setEnabled(true);

        String text =
            "✓ VALORANT Mobile detectado\n\n" +
            "RAM total: " +
            formatRam(totalRam) +
            "\n" +
            "RAM disponível: " +
            formatRam(availableRam) +
            "\n";

        if (ramOk) {

            text +=
                "✓ Dispositivo compatível\n";

        } else {

            text +=
                "⚠ Abaixo de 3 GB\n";
        }

        text += "\n";

        if (ultra) {

            text +=
                "Desempenho Ultra: ATIVADO";

        } else {

            text +=
                "Desempenho Ultra: DESATIVADO";
        }

        statusText.setText(text);
    }

    private void openValorant() {

        Intent intent =
            getPackageManager()
                .getLaunchIntentForPackage(
                    VALORANT_PACKAGE
                );

        if (intent == null) {

            statusText.setText(
                "VALORANT Mobile não encontrado."
            );

            return;
        }

        boolean ultra =
            preferences.getBoolean(
                "ultraPerformance",
                false
            );

        long availableRam =
            getAvailableRam();

        if (ultra) {

            statusText.setText(
                "Desempenho Ultra ativado\n\n" +
                "RAM disponível: " +
                formatRam(availableRam) +
                "\n\n" +
                "Iniciando VALORANT Mobile..."
            );

        } else {

            statusText.setText(
                "Iniciando VALORANT Mobile..."
            );
        }

        intent.addFlags(
            Intent.FLAG_ACTIVITY_NO_ANIMATION
        );

        startActivity(intent);
    }
}