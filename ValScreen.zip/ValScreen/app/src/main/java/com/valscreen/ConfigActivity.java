package com.valscreen;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

public class ConfigActivity extends Activity {

    private Switch ultraSwitch;
    private Button applyButton;
    private Button backButton;
    private TextView statusText;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.config);

        ultraSwitch = (Switch)
            findViewById(R.id.ultraSwitch);

        applyButton = (Button)
            findViewById(R.id.applyButton);

        backButton = (Button)
            findViewById(R.id.backButton);

        statusText = (TextView)
            findViewById(R.id.statusText);

        preferences = getSharedPreferences(
            "ValScreenSettings",
            MODE_PRIVATE
        );

        loadSettings();

        applyButton.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveSettings();
                }
            }
        );

        backButton.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            }
        );
    }

    private void loadSettings() {

        boolean enabled =
            preferences.getBoolean(
                "ultraPerformance",
                false
            );

        ultraSwitch.setChecked(enabled);

        updateStatus(enabled);
    }

    private void saveSettings() {

        boolean enabled =
            ultraSwitch.isChecked();

        preferences.edit()
            .putBoolean(
                "ultraPerformance",
                enabled
            )
            .apply();

        updateStatus(enabled);
    }

    private void updateStatus(boolean enabled) {

        if (enabled) {

            statusText.setText(
                "Status: Desempenho Ultra ativado"
            );

        } else {

            statusText.setText(
                "Status: Desempenho Ultra desativado"
            );
        }
    }
}